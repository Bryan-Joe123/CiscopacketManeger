from controller import Robot,Keyboard

robot = Robot()
keyboard = Keyboard()
timestep = 64

Amotor = robot.getDevice("B motor")
Bmotor = robot.getDevice("A motor")
Cmotor = robot.getDevice("C motor")
Dmotor = robot.getDevice("D motor")
Emotor = robot.getDevice("E motor")
Fmotor = robot.getDevice("F motor")

keyboard.enable(timestep)

AmotorPos = 0
BmotorPos = 0
CmotorPos = 0
DmotorPos = 0
EmotorPos = 0
FmotorPos = 0


def move(a=0,b=0,c=0,d=0,e=0,f=0):
    Amotor.setPosition(a)
    Bmotor.setPosition(b)
    Cmotor.setPosition(c)
    Dmotor.setPosition(d)
    Emotor.setPosition(e)
    Fmotor.setPosition(f)


while robot.step(timestep)!=-1:
    keypressed = keyboard.getKey()
    if keypressed == 317:
        AmotorPos+=0.01
    elif keypressed == 315:
        AmotorPos-=0.01
        
    elif keypressed == 316:
        BmotorPos-=0.01
    elif keypressed == 314:
        BmotorPos+=0.01
        
    elif keypressed == 87:
        CmotorPos-=0.01
    elif keypressed == 83:
        CmotorPos+=0.01
    
    elif keypressed == 65:
        DmotorPos-=0.01
    elif keypressed == 68:
        DmotorPos+=0.01
        
    elif keypressed == 49:
        EmotorPos+=0.01
    elif keypressed == 50:
        EmotorPos-=0.01
        
        
    elif keypressed == 51:
        FmotorPos+=0.01
    elif keypressed == 52:
        FmotorPos-=0.01
    
    move(AmotorPos,BmotorPos,CmotorPos,DmotorPos,EmotorPos,FmotorPos)
    